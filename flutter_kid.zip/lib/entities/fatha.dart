class fathaEntity {
  String text;
  String audio;

 fathaEntity({
    this.text,
    this.audio,
  });

  factory fathaEntity.fromJson(Map<String, dynamic> parsedJson) {
    return fathaEntity(
      text: parsedJson['text'],
      audio: parsedJson['audio'],
    );
  }
}
