class wordEntity {
  String text;
  String audio;

  wordEntity({
    this.text,
    this.audio,
  });

  factory wordEntity.fromJson(Map<String, dynamic> parsedJson) {
    return wordEntity(
      text: parsedJson['text'],
      audio: parsedJson['audio'],
    );
  }
}
