class dammaEntity {
  String text;
  String audio;

  dammaEntity({
    this.text,
    this.audio,
  });

  factory dammaEntity.fromJson(Map<String, dynamic> parsedJson) {
    return dammaEntity(
      text: parsedJson['text'],
      audio: parsedJson['audio'],
    );
  }
}
