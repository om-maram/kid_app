class kasrahEntity {
  String text;
  String audio;

  kasrahEntity({
    this.text,
    this.audio,
  });

  factory kasrahEntity.fromJson(Map<String, dynamic> parsedJson) {
    return kasrahEntity(
      text: parsedJson['text'],
      audio: parsedJson['audio'],
    );
  }
}
