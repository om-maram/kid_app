import 'package:flutter/material.dart';
import 'package:kidstarter/screens/alphabets.dart';
import 'package:kidstarter/screens/colors.dart';
import 'package:kidstarter/screens/counting.dart';
import 'package:kidstarter/screens/shapes.dart';
import 'package:kidstarter/screens/stories.dart';
import 'package:kidstarter/widgets/category_card.dart';

class writeScreen extends StatelessWidget {
  final List<Widget> _categories = [
    CategoryCard(
      title: 'أ',
      primaryColor: Colors.orangeAccent[100],
      secondaryColor: Colors.orange,
      screen:  StoriesScreen(
        title: 'أ',
        primaryColor: Colors.orangeAccent[100],
        secondaryColor: Colors.orange,
      ),
    ),
    CategoryCard(
      title: 'ب',
      primaryColor: Colors.orangeAccent[100],
      secondaryColor: Colors.orange,
      screen:  StoriesScreen(
        title: 'ب',
        primaryColor: Colors.orangeAccent[100],
        secondaryColor: Colors.orange,
      ),
    ),
    CategoryCard(
      title: 'ت',
      primaryColor: Colors.orangeAccent[100],
      secondaryColor: Colors.orange,
      screen:  StoriesScreen(
        title: 'ت',
        primaryColor: Colors.orangeAccent[100],
        secondaryColor: Colors.orange,
      ),
    ),
    CategoryCard(
      title: 'ث',
      primaryColor: Colors.orangeAccent[100],
      secondaryColor: Colors.orange,
      screen:  StoriesScreen(
        title: 'ث',
        primaryColor: Colors.orangeAccent[100],
        secondaryColor: Colors.orange,
      ),
    ),
    CategoryCard(
      title: 'ج',
      primaryColor: Colors.orangeAccent[100],
      secondaryColor: Colors.orange,
      screen:  StoriesScreen(
        title: 'ج',
        primaryColor: Colors.orangeAccent[100],
        secondaryColor: Colors.orange,
      ),
    ),
    CategoryCard(
      title: 'ح',
      primaryColor: Colors.orangeAccent[100],
      secondaryColor: Colors.orange,
      screen:  StoriesScreen(
        title: 'ح',
        primaryColor: Colors.orangeAccent[100],
        secondaryColor: Colors.orange,
      ),
    ),
    CategoryCard(
      title: 'خ',
      primaryColor: Colors.orangeAccent[100],
      secondaryColor: Colors.orange,
      screen:  StoriesScreen(
        title: 'خ',
        primaryColor: Colors.orangeAccent[100],
        secondaryColor: Colors.orange,
      ),
    ),
    CategoryCard(
      title: 'د',
      primaryColor: Colors.orangeAccent[100],
      secondaryColor: Colors.orange,
      screen:  StoriesScreen(
        title: 'د',
        primaryColor: Colors.orangeAccent[100],
        secondaryColor: Colors.orange,
      ),
    ),
    CategoryCard(
      title: 'ذ',
      primaryColor: Colors.orangeAccent[100],
      secondaryColor: Colors.orange,
      screen:  StoriesScreen(
        title: 'ذ',
        primaryColor: Colors.orangeAccent[100],
        secondaryColor: Colors.orange,
      ),
    ),
    CategoryCard(
      title: 'ر',
      primaryColor: Colors.orangeAccent[100],
      secondaryColor: Colors.orange,
      screen:  StoriesScreen(
        title: 'ر',
        primaryColor: Colors.orangeAccent[100],
        secondaryColor: Colors.orange,
      ),
    ),
    CategoryCard(
      title: 'ز',
      primaryColor: Colors.orangeAccent[100],
      secondaryColor: Colors.orange,
      screen:  StoriesScreen(
        title: 'ز',
        primaryColor: Colors.orangeAccent[100],
        secondaryColor: Colors.orange,
      ),
    ),
    CategoryCard(
      title: 'س',
      primaryColor: Colors.orangeAccent[100],
      secondaryColor: Colors.orange,
      screen:  StoriesScreen(
        title: 'س',
        primaryColor: Colors.orangeAccent[100],
        secondaryColor: Colors.orange,
      ),
    ),
    CategoryCard(
      title: 'ش',
      primaryColor: Colors.orangeAccent[100],
      secondaryColor: Colors.orange,
      screen:  StoriesScreen(
        title: 'ش',
        primaryColor: Colors.orangeAccent[100],
        secondaryColor: Colors.orange,
      ),
    ),
    CategoryCard(
      title: 'ص',
      primaryColor: Colors.orangeAccent[100],
      secondaryColor: Colors.orange,
      screen:  StoriesScreen(
        title: 'ص',
        primaryColor: Colors.orangeAccent[100],
        secondaryColor: Colors.orange,
      ),
    ),
    CategoryCard(
      title: 'ض',
      primaryColor: Colors.orangeAccent[100],
      secondaryColor: Colors.orange,
      screen:  StoriesScreen(
        title: 'ض',
        primaryColor: Colors.orangeAccent[100],
        secondaryColor: Colors.orange,
      ),
    ),
    CategoryCard(
      title: 'ط',
      primaryColor: Colors.orangeAccent[100],
      secondaryColor: Colors.orange,
      screen:  StoriesScreen(
        title: 'ط',
        primaryColor: Colors.orangeAccent[100],
        secondaryColor: Colors.orange,
      ),
    ),
    CategoryCard(
      title: 'ظ',
      primaryColor: Colors.orangeAccent[100],
      secondaryColor: Colors.orange,
      screen:  StoriesScreen(
        title: 'ظ',
        primaryColor: Colors.orangeAccent[100],
        secondaryColor: Colors.orange,
      ),
    ),

    CategoryCard(
      title: 'ع',
      primaryColor: Colors.orangeAccent[100],
      secondaryColor: Colors.orange,
      screen:  StoriesScreen(
        title: 'ع',
        primaryColor: Colors.orangeAccent[100],
        secondaryColor: Colors.orange,
      ),
    ),
    CategoryCard(
      title: 'غ',
      primaryColor: Colors.orangeAccent[100],
      secondaryColor: Colors.orange,
      screen:  StoriesScreen(
        title: 'غ',
        primaryColor: Colors.orangeAccent[100],
        secondaryColor: Colors.orange,
      ),
    ),
    CategoryCard(
      title: 'ق',
      primaryColor: Colors.orangeAccent[100],
      secondaryColor: Colors.orange,
      screen:  StoriesScreen(
        title: 'ق',
        primaryColor: Colors.orangeAccent[100],
        secondaryColor: Colors.orange,
      ),
    ),
    CategoryCard(
      title: 'ك',
      primaryColor: Colors.orangeAccent[100],
      secondaryColor: Colors.orange,
      screen:  StoriesScreen(
        title: 'ك',
        primaryColor: Colors.orangeAccent[100],
        secondaryColor: Colors.orange,
      ),
    ),
    CategoryCard(
      title: 'ل',
      primaryColor: Colors.orangeAccent[100],
      secondaryColor: Colors.orange,
      screen:  StoriesScreen(
        title: 'ل',
        primaryColor: Colors.orangeAccent[100],
        secondaryColor: Colors.orange,
      ),
    ),
    CategoryCard(
      title: 'م',
      primaryColor: Colors.orangeAccent[100],
      secondaryColor: Colors.orange,
      screen:  StoriesScreen(
        title: 'م',
        primaryColor: Colors.orangeAccent[100],
        secondaryColor: Colors.orange,
      ),
    ),
    CategoryCard(
      title: 'ن',
      primaryColor: Colors.orangeAccent[100],
      secondaryColor: Colors.orange,
      screen:  StoriesScreen(
        title: 'ن',
        primaryColor: Colors.orangeAccent[100],
        secondaryColor: Colors.orange,
      ),
    ),
    CategoryCard(
      title: 'هـ',
      primaryColor: Colors.orangeAccent[100],
      secondaryColor: Colors.orange,
      screen:  StoriesScreen(
        title: 'هـ',
        primaryColor: Colors.orangeAccent[100],
        secondaryColor: Colors.orange,
      ),
    ),
    CategoryCard(
      title: 'و',
      primaryColor: Colors.orangeAccent[100],
      secondaryColor: Colors.orange,
      screen:  StoriesScreen(
        title: 'و',
        primaryColor: Colors.orangeAccent[100],
        secondaryColor: Colors.orange,
      ),
    ),
    CategoryCard(
      title: 'ي',
      primaryColor: Colors.orangeAccent[100],
      secondaryColor: Colors.orange,
      screen:  StoriesScreen(
        title: 'ي',
        primaryColor: Colors.orangeAccent[100],
        secondaryColor: Colors.orange,
      ),
    )

  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(

        child: CustomScrollView(
          slivers: <Widget>[
            SliverAppBar(
              expandedHeight: 50.0,
              backgroundColor: Colors.grey[50],
              flexibleSpace: FlexibleSpaceBar(

              ),
            ),
            SliverList(
              delegate: SliverChildListDelegate(_categories),
            ),
          ],
        ),
      ),
    );
  }
}
