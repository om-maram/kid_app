import 'package:flutter/material.dart';
import 'package:kidstarter/constant.dart';
import 'package:kidstarter/widgets/page_header.dart';
import 'package:webview_flutter/webview_flutter.dart';
class vedioScreen extends StatelessWidget {
  final String title;
  final Color primaryColor;
  final Color secondaryColor;

  const vedioScreen({
    this.title,
    this.primaryColor,
    this.secondaryColor,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body:
      Container(
         child:
      WebView(
                javascriptMode: JavascriptMode.unrestricted,
                initialUrl: "https://www.a966a.com/app2021/index2.aspx"),

      ),
    );
  }
}
