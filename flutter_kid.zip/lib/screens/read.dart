import 'package:flutter/material.dart';
import 'package:kidstarter/screens/alphabets.dart';
import 'package:kidstarter/screens/dammas.dart';
import 'package:kidstarter/screens/fathas.dart';
import 'package:kidstarter/screens/kasrahs.dart';
import 'package:kidstarter/screens/words.dart';

import 'package:kidstarter/screens/stories.dart';
import 'package:kidstarter/widgets/category_card.dart';

class readScreen extends StatelessWidget {
  final List<Widget> _categories = [
    CategoryCard(
      title: 'الحروف الأبجدية',
      primaryColor: Colors.orangeAccent[100],
      secondaryColor: Colors.orange,
      screen:  AlphabetsScreen(
        title: 'الحروف الأبجدية',
        primaryColor: Colors.orangeAccent[100],
        secondaryColor: Colors.orange,
      ),
    ),
    CategoryCard(
      title: 'الفتحة',
      primaryColor: Colors.greenAccent[100],
      secondaryColor: Colors.green,
      screen: fathasScreen(
        title: 'الفتحة',
        primaryColor: Colors.greenAccent[100],
        secondaryColor: Colors.green,
      ),
    ),
    CategoryCard(
      title: 'الكسرة',
      primaryColor: Colors.purpleAccent[100],
      secondaryColor: Colors.purple,
      screen:  kasrahsScreen(
        title: 'الكسرة',
        primaryColor: Colors.purpleAccent[100],
        secondaryColor: Colors.purple,
      ),
    ),
    CategoryCard(
      title: 'الضمة',
      primaryColor: Color(0xFF3383CD),
      secondaryColor: Color(0xFF11249F),
      screen: dammasScreen(
        title: 'الضمة',
        primaryColor: Color(0xFF3383CD),
        secondaryColor: Color(0xFF11249F),
      ),
    ),
    CategoryCard(
      title: 'كلمات بالفتحة',
      primaryColor: Colors.redAccent[100],
      secondaryColor: Colors.red,
      screen: wordsScreen(
        title: 'كلمات بالفتحة',
        primaryColor: Colors.redAccent[100],
        secondaryColor: Colors.red,
      ),
    ),

    CategoryCard(
      title: 'كلمات بالكسرة',
      primaryColor: Colors.redAccent[100],
      secondaryColor: Colors.pink,
      screen: StoriesScreen(
        title: 'كلمات بالكسرة',
        primaryColor: Colors.redAccent[100],
        secondaryColor: Colors.pink,
      ),
    ),

    CategoryCard(
      title: 'كلمات بالضمة',
      primaryColor: Colors.redAccent[100],
      secondaryColor: Colors.yellow,
      screen:StoriesScreen  (
        title: 'كلمات بالضمة',
        primaryColor: Colors.redAccent[100],
        secondaryColor: Colors.yellow,
      ),
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          color: Colors.grey[50],
          image: DecorationImage(
            image: AssetImage('assets/images/bg-bottom.png'),
            alignment: Alignment.bottomCenter,
          ),
        ),
        child: CustomScrollView(
          slivers: <Widget>[
            SliverAppBar(
              expandedHeight: 188.0,
              backgroundColor: Colors.grey[50],
              flexibleSpace: FlexibleSpaceBar(
                background: Image.asset(
                  'assets/images/bg-top.png',
                  fit: BoxFit.cover,
                  alignment: Alignment.topCenter,
                ),
              ),
            ),
            SliverList(
              delegate: SliverChildListDelegate(_categories),
            ),
          ],
        ),
      ),
    );
  }
}
